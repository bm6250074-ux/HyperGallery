# HyperGallery

Gallery app inspired by the Xiaomi HyperOS 4 Gallery (Kotlin + Jetpack Compose).

## Build the APK with GitHub Actions
1. Create a new GitHub repository and upload everything in this folder (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab, choose **Build HyperGallery APK**, press **Run workflow** (it also runs on every push).
3. When it finishes, download the APK from **Artifacts** (`HyperGallery-release`) or from the repository **Releases** page.
