package com.hyper.gallery

import android.app.Application
import android.content.Context
import android.database.ContentObserver
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.hyper.gallery.data.AlbumEntry
import com.hyper.gallery.data.LabelStore
import com.hyper.gallery.data.MediaEntry
import com.hyper.gallery.data.MediaRepository
import com.hyper.gallery.data.MonthEntry
import com.hyper.gallery.data.SmartAlbum
import com.hyper.gallery.data.SmartDefs
import com.hyper.gallery.data.YearEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.Month
import java.time.format.TextStyle
import java.util.Locale
import kotlin.coroutines.resume

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val prefs = app.getSharedPreferences("gallery_prefs", Context.MODE_PRIVATE)
    private val labels = LabelStore(app)

    var media by mutableStateOf<List<MediaEntry>>(emptyList())
        private set
    var trashed by mutableStateOf<List<MediaEntry>>(emptyList())
        private set
    var favorites by mutableStateOf(readSet("fav"))
        private set
    var hidden by mutableStateOf(readSet("hidden"))
        private set
    var loading by mutableStateOf(true)
        private set
    var zoom by mutableIntStateOf(prefs.getInt("zoom", 1))
        private set
    var analyzed by mutableIntStateOf(0)
        private set
    var analyzeTotal by mutableIntStateOf(0)
        private set
    var labelVersion by mutableIntStateOf(0)
        private set

    /** Item opened from another app (ACTION_VIEW) that is not necessarily in MediaStore. */
    var external: MediaEntry? = null

    private var mediaMap: Map<Long, MediaEntry> = emptyMap()
    private var trashMap: Map<Long, MediaEntry> = emptyMap()

    val visible: List<MediaEntry> by derivedStateOf { media.filter { it.id !in hidden } }
    val hiddenItems: List<MediaEntry> by derivedStateOf { media.filter { it.id in hidden } }
    val favoriteItems: List<MediaEntry> by derivedStateOf { visible.filter { it.id in favorites } }
    val videos: List<MediaEntry> by derivedStateOf { visible.filter { it.isVideo } }
    val screenshots: List<MediaEntry> by derivedStateOf { visible.filter { it.isScreenshot } }

    val albums: List<AlbumEntry> by derivedStateOf {
        visible.groupBy { it.bucketId }
            .map { (id, list) ->
                AlbumEntry("bucket:$id", list.first().bucketName.ifBlank { "?" }, list.size, list.first())
            }
            .sortedWith(
                compareByDescending<AlbumEntry> { it.name.equals("Camera", ignoreCase = true) }
                    .thenByDescending { it.count }
            )
    }

    val months: List<MonthEntry> by derivedStateOf {
        visible.groupBy { it.localDate.year * 100 + it.localDate.monthValue }
            .entries.sortedByDescending { it.key }
            .map { (k, list) -> MonthEntry("${k / 100}-${k % 100}", k / 100, k % 100, list.size, list.first()) }
    }

    val onThisDayYears: List<YearEntry> by derivedStateOf {
        val today = LocalDate.now()
        visible.filter {
            val d = it.localDate
            d.monthValue == today.monthValue && d.dayOfMonth == today.dayOfMonth && d.year < today.year
        }.groupBy { it.localDate.year }
            .entries.sortedByDescending { it.key }
            .map { (y, list) -> YearEntry(y, list.size, list.first()) }
    }

    val smartAlbums: List<SmartAlbum> by derivedStateOf {
        @Suppress("UNUSED_VARIABLE") val v = labelVersion
        SmartDefs.mapNotNull { def ->
            val list = visible.filter { e -> labels.get(e.id).any { l -> l in def.words } }
            if (list.isEmpty()) null else SmartAlbum(def, list.size, list.first())
        }
    }

    private var refreshJob: Job? = null
    private var analysisJob: Job? = null

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            scheduleRefresh()
        }
    }

    init {
        val r = app.contentResolver
        r.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        r.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
        refresh()
    }

    override fun onCleared() {
        getApplication<Application>().contentResolver.unregisterContentObserver(observer)
        super.onCleared()
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            delay(600)
            doRefresh()
        }
    }

    fun refresh() {
        viewModelScope.launch { doRefresh() }
    }

    private suspend fun doRefresh() {
        val (m, t) = withContext(Dispatchers.IO) {
            repo.load(false).sortedByDescending { it.date } to
                repo.load(true).sortedByDescending { it.date }
        }
        mediaMap = m.associateBy { it.id }
        trashMap = t.associateBy { it.id }
        media = m
        trashed = t
        loading = false
        startAnalysis()
    }

    fun find(id: Long): MediaEntry? {
        if (id == -1L) return external
        return mediaMap[id] ?: trashMap[id]
    }

    // ---- user state ----

    private fun readSet(key: String): Set<Long> =
        prefs.getStringSet(key, emptySet())?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()

    private fun writeSet(key: String, set: Set<Long>) {
        prefs.edit().putStringSet(key, set.map { it.toString() }.toSet()).apply()
    }

    fun toggleFavorite(ids: Collection<Long>) {
        val all = ids.all { it in favorites }
        favorites = if (all) favorites - ids.toSet() else favorites + ids
        writeSet("fav", favorites)
    }

    fun hide(ids: Collection<Long>) {
        hidden = hidden + ids
        writeSet("hidden", hidden)
    }

    fun unhide(ids: Collection<Long>) {
        hidden = hidden - ids.toSet()
        writeSet("hidden", hidden)
    }

    fun changeZoom(delta: Int) {
        val z = (zoom + delta).coerceIn(0, 3)
        if (z != zoom) {
            zoom = z
            prefs.edit().putInt("zoom", z).apply()
        }
    }

    // ---- collections ----

    fun itemsFor(key: String): List<MediaEntry> = when {
        key == "fav" -> favoriteItems
        key == "videos" -> videos
        key == "shots" -> screenshots
        key == "hidden" -> hiddenItems
        key.startsWith("bucket:") -> {
            val id = key.removePrefix("bucket:").toLongOrNull()
            visible.filter { it.bucketId == id }
        }
        key.startsWith("month:") -> {
            val p = key.removePrefix("month:").split('-')
            val y = p.getOrNull(0)?.toIntOrNull()
            val m = p.getOrNull(1)?.toIntOrNull()
            visible.filter { it.localDate.year == y && it.localDate.monthValue == m }
        }
        key.startsWith("otd:") -> {
            val y = key.removePrefix("otd:").toIntOrNull()
            val today = LocalDate.now()
            visible.filter {
                val d = it.localDate
                d.year == y && d.monthValue == today.monthValue && d.dayOfMonth == today.dayOfMonth
            }
        }
        key.startsWith("smart:") -> {
            val def = SmartDefs.firstOrNull { it.id == key.removePrefix("smart:") }
            if (def == null) emptyList()
            else visible.filter { e -> labels.get(e.id).any { l -> l in def.words } }
        }
        else -> emptyList()
    }

    /** filter: 0 all, 1 photos, 2 videos, 3 screenshots, 4 favorites */
    fun search(query: String, filter: Int): List<MediaEntry> {
        val tokens = query.lowercase().trim().split(' ').filter { it.isNotEmpty() }
        val locale = Locale.getDefault()
        val monthNames = Month.values().associateWith {
            listOf(
                it.getDisplayName(TextStyle.FULL, locale).lowercase(),
                it.getDisplayName(TextStyle.FULL, Locale.ENGLISH).lowercase()
            )
        }
        return visible.filter { e ->
            val passFilter = when (filter) {
                1 -> !e.isVideo
                2 -> e.isVideo
                3 -> e.isScreenshot
                4 -> e.id in favorites
                else -> true
            }
            passFilter && tokens.all { t ->
                e.name.lowercase().contains(t) ||
                    e.bucketName.lowercase().contains(t) ||
                    (e.isVideo && "video".startsWith(t)) ||
                    (!e.isVideo && ("photo".startsWith(t) || "image".startsWith(t))) ||
                    labels.get(e.id).any { it.contains(t) } ||
                    dateMatches(t, e.localDate, monthNames)
            }
        }
    }

    private fun dateMatches(token: String, d: LocalDate, names: Map<Month, List<String>>): Boolean {
        val n = token.toIntOrNull()
        if (n != null) {
            return if (n >= 1900) d.year == n else n in 1..31 && d.dayOfMonth == n
        }
        if (token.length < 3) return false
        return names[d.month]?.any { it.startsWith(token) } == true
    }

    // ---- on-device AI scan (ML Kit image labeling) ----

    private fun startAnalysis() {
        if (analysisJob?.isActive == true) return
        analysisJob = viewModelScope.launch(Dispatchers.Default) {
            val all = media
            val pending = all.filter { !labels.has(it.id) }
            analyzeTotal = all.size
            analyzed = all.size - pending.size
            if (pending.isEmpty()) return@launch

            val labeler = ImageLabeling.getClient(
                ImageLabelerOptions.Builder().setConfidenceThreshold(0.65f).build()
            )
            try {
                var n = 0
                for (item in pending) {
                    ensureActive()
                    val bmp = loadThumb(item)
                    val found = if (bmp != null) label(labeler, bmp) else emptyList()
                    labels.put(item.id, found)
                    analyzed += 1
                    n++
                    if (n % 25 == 0) labelVersion += 1
                }
            } finally {
                labeler.close()
                labelVersion += 1
            }
        }
    }

    private fun loadThumb(item: MediaEntry): Bitmap? {
        return try {
            val b = getApplication<Application>().contentResolver
                .loadThumbnail(item.uri, Size(256, 256), null)
            if (b.config == Bitmap.Config.HARDWARE) b.copy(Bitmap.Config.ARGB_8888, false) else b
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun label(labeler: ImageLabeler, bmp: Bitmap): List<String> =
        suspendCancellableCoroutine { cont ->
            labeler.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { res -> if (cont.isActive) cont.resume(res.map { it.text }) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }
}
