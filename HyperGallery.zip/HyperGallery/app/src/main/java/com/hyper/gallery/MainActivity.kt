package com.hyper.gallery

import android.Manifest
import android.app.KeyguardManager
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.hyper.gallery.data.MediaEntry
import com.hyper.gallery.ui.AboutScreen
import com.hyper.gallery.ui.AlbumDetailScreen
import com.hyper.gallery.ui.EditorScreen
import com.hyper.gallery.ui.GalleryTheme
import com.hyper.gallery.ui.HiddenScreen
import com.hyper.gallery.ui.HomeScreen
import com.hyper.gallery.ui.LocalActions
import com.hyper.gallery.ui.MediaActions
import com.hyper.gallery.ui.Navigator
import com.hyper.gallery.ui.PermissionScreen
import com.hyper.gallery.ui.Screen
import com.hyper.gallery.ui.SearchScreen
import com.hyper.gallery.ui.TrashScreen
import com.hyper.gallery.ui.ViewerScreen

class MainActivity : ComponentActivity() {

    private val vm: GalleryViewModel by viewModels()
    private val stack: SnapshotStateList<Screen> = mutableStateListOf()
    private var granted by mutableStateOf(false)
    private var pendingDone: (() -> Unit)? = null
    private var pendingAuth: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            granted = hasAccess()
            if (granted) vm.refresh()
        }

    private val sender =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) pendingDone?.invoke()
            pendingDone = null
            vm.refresh()
        }

    private val authLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) pendingAuth?.invoke()
            pendingAuth = null
        }

    private fun permissions(): Array<String> = if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasAccess(): Boolean = permissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun request(createRequest: () -> android.app.PendingIntent, done: () -> Unit) {
        try {
            pendingDone = done
            sender.launch(IntentSenderRequest.Builder(createRequest().intentSender).build())
        } catch (e: Exception) {
            pendingDone = null
            Toast.makeText(this, R.string.action_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun uris(list: List<MediaEntry>) = list.map { it.uri }

    private val actions by lazy {
        MediaActions(
            trash = { list, done ->
                request({ MediaStore.createTrashRequest(contentResolver, uris(list), true) }, done)
            },
            restore = { list, done ->
                request({ MediaStore.createTrashRequest(contentResolver, uris(list), false) }, done)
            },
            deleteForever = { list, done ->
                request({ MediaStore.createDeleteRequest(contentResolver, uris(list)) }, done)
            },
            share = { list -> share(list) },
            setAs = { e ->
                val i = Intent(Intent.ACTION_ATTACH_DATA).apply {
                    setDataAndType(e.uri, e.mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    putExtra("mimeType", e.mime)
                }
                startActivity(Intent.createChooser(i, getString(R.string.set_as)))
            },
            authenticate = { next -> authenticate(next) }
        )
    }

    private fun share(list: List<MediaEntry>) {
        if (list.isEmpty()) return
        val i = if (list.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = list[0].mime
                putExtra(Intent.EXTRA_STREAM, list[0].uri)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = if (list.all { it.isVideo }) "video/*" else if (list.none { it.isVideo }) "image/*" else "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(uris(list)))
            }
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, getString(R.string.share)))
    }

    private fun authenticate(next: () -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            next()
            return
        }
        @Suppress("DEPRECATION")
        val i = km.createConfirmDeviceCredentialIntent(
            getString(R.string.hidden_album),
            getString(R.string.auth_msg)
        )
        if (i == null) {
            next()
            return
        }
        pendingAuth = next
        authLauncher.launch(i)
    }

    private fun handleIntent(i: Intent?) {
        val data = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW) return
        val mime = i.type ?: contentResolver.getType(data) ?: "image/*"
        val e = MediaEntry(
            id = -1L, uri = data, name = data.lastPathSegment ?: "", mime = mime,
            isVideo = mime.startsWith("video"), date = System.currentTimeMillis(),
            size = 0, width = 0, height = 0, duration = 0, bucketId = 0,
            bucketName = "", path = "", expires = 0
        )
        vm.external = e
        stack.clear()
        stack.add(Screen.Viewer(listOf(-1L), 0))
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        granted = hasAccess()
        if (!granted) permissionLauncher.launch(permissions())
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            GalleryTheme {
                val nav = remember { Navigator(stack) }
                var tab by remember { mutableIntStateOf(0) }
                CompositionLocalProvider(LocalActions provides actions) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        if (!granted) {
                            PermissionScreen { permissionLauncher.launch(permissions()) }
                        } else {
                            BackHandler(enabled = stack.isNotEmpty()) { nav.pop() }
                            AnimatedContent(
                                targetState = stack.lastOrNull(),
                                transitionSpec = {
                                    if (targetState != null) {
                                        (slideInHorizontally { it / 4 } + fadeIn()) togetherWith fadeOut()
                                    } else {
                                        fadeIn() togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
                                    }
                                },
                                label = "nav"
                            ) { screen ->
                                when (screen) {
                                    null -> HomeScreen(vm, nav, tab) { tab = it }
                                    is Screen.AlbumDetail -> AlbumDetailScreen(vm, nav, screen.key, screen.title)
                                    is Screen.Viewer -> ViewerScreen(vm, nav, screen.ids, screen.index, screen.trash)
                                    is Screen.Editor -> EditorScreen(vm, nav, screen.id)
                                    Screen.Search -> SearchScreen(vm, nav)
                                    Screen.Trash -> TrashScreen(vm, nav)
                                    Screen.Hidden -> HiddenScreen(vm, nav)
                                    Screen.About -> AboutScreen(nav)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val now = hasAccess()
        if (now != granted) granted = now
        if (now) vm.refresh()
    }
}
