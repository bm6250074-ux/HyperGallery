package com.hyper.gallery.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import java.io.File

class MediaRepository(private val context: Context) {

    private val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.DISPLAY_NAME,
        MediaStore.Files.FileColumns.MIME_TYPE,
        MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.Files.FileColumns.DATE_ADDED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.Files.FileColumns.SIZE,
        MediaStore.MediaColumns.WIDTH,
        MediaStore.MediaColumns.HEIGHT,
        MediaStore.MediaColumns.DURATION,
        MediaStore.MediaColumns.BUCKET_ID,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.RELATIVE_PATH,
        MediaStore.MediaColumns.DATE_EXPIRES
    )

    /** Loads all images and videos. When [trashed] is true only items in the recycle bin are returned. */
    fun load(trashed: Boolean): List<MediaEntry> {
        val list = ArrayList<MediaEntry>()
        val selection =
            "${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?"
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(
                ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS,
                arrayOf(
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
                    MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                )
            )
            putInt(
                MediaStore.QUERY_ARG_MATCH_TRASHED,
                if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE
            )
        }
        val cursor = try {
            context.contentResolver.query(
                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL),
                projection,
                args,
                null
            )
        } catch (e: Exception) {
            null
        } ?: return list

        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
            val iType = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_ADDED)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val iW = c.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
            val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_ID)
            val iBucketName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val iPath = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val iExp = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_EXPIRES)

            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                val taken = c.getLong(iTaken)
                val date = if (taken > 0) taken else c.getLong(iAdded) * 1000L
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                list.add(
                    MediaEntry(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        name = c.getString(iName) ?: "",
                        mime = c.getString(iMime) ?: if (video) "video/*" else "image/*",
                        isVideo = video,
                        date = date,
                        size = c.getLong(iSize),
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        duration = c.getLong(iDur),
                        bucketId = c.getLong(iBucket),
                        bucketName = c.getString(iBucketName) ?: "",
                        path = c.getString(iPath) ?: "",
                        expires = c.getLong(iExp)
                    )
                )
            }
        }
        return list
    }
}

/** Tiny on-device store for the image labels produced by the AI scan (id -> labels). */
class LabelStore(context: Context) {
    private val file = File(context.filesDir, "ai_labels.tsv")
    private val map = HashMap<Long, Set<String>>()

    init {
        try {
            if (file.exists()) {
                file.forEachLine { line ->
                    val parts = line.split('\t')
                    val id = parts[0].toLongOrNull()
                    if (id != null) {
                        map[id] = if (parts.size > 1 && parts[1].isNotEmpty())
                            parts[1].split(',').toSet() else emptySet()
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun has(id: Long): Boolean = map.containsKey(id)

    @Synchronized
    fun get(id: Long): Set<String> = map[id] ?: emptySet()

    @Synchronized
    fun put(id: Long, labels: Collection<String>) {
        val set = labels.map { it.lowercase().replace(",", " ").replace("\t", " ") }.toSet()
        map[id] = set
        try {
            file.appendText("$id\t${set.joinToString(",")}\n")
        } catch (_: Exception) {
        }
    }
}
