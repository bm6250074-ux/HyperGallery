package com.hyper.gallery.data

import android.net.Uri
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class MediaEntry(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val isVideo: Boolean,
    val date: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val duration: Long,
    val bucketId: Long,
    val bucketName: String,
    val path: String,
    val expires: Long
) {
    val localDate: LocalDate by lazy(LazyThreadSafetyMode.NONE) {
        Instant.ofEpochMilli(date).atZone(ZoneId.systemDefault()).toLocalDate()
    }

    val isScreenshot: Boolean
        get() = path.contains("screenshot", ignoreCase = true) ||
            bucketName.contains("screenshot", ignoreCase = true)
}

data class AlbumEntry(
    val key: String,
    val name: String,
    val count: Int,
    val cover: MediaEntry
)

data class MonthEntry(
    val key: String,
    val year: Int,
    val month: Int,
    val count: Int,
    val cover: MediaEntry
)

data class YearEntry(
    val year: Int,
    val count: Int,
    val cover: MediaEntry
)

data class SmartDef(val id: String, val words: Set<String>)

data class SmartAlbum(
    val def: SmartDef,
    val count: Int,
    val cover: MediaEntry
)

val SmartDefs = listOf(
    SmartDef("people", setOf("selfie", "smile", "face", "person", "portrait", "crowd", "child", "baby", "beard", "hair", "skin", "fun", "event")),
    SmartDef("pets", setOf("dog", "cat", "pet", "puppy", "kitten", "bird", "animal", "horse", "fish")),
    SmartDef("food", setOf("food", "dish", "meal", "cuisine", "dessert", "fruit", "vegetable", "drink", "cake", "pizza", "coffee", "tableware", "baked goods")),
    SmartDef("nature", setOf("sky", "flower", "tree", "mountain", "beach", "sea", "cloud", "sunset", "sunrise", "plant", "grass", "lake", "forest", "nature", "sand", "water")),
    SmartDef("buildings", setOf("building", "skyline", "city", "tower", "architecture", "bridge", "house", "street", "urban area")),
    SmartDef("vehicles", setOf("car", "vehicle", "motorcycle", "bicycle", "airplane", "truck", "bus", "wheel", "boat", "train")),
    SmartDef("documents", setOf("text", "document", "paper", "receipt", "poster", "handwriting", "font", "screenshot"))
)
