@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hyper.gallery.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.hyper.gallery.GalleryViewModel
import com.hyper.gallery.R
import com.hyper.gallery.data.MediaEntry
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Grouping { NONE, DAY, MONTH }

enum class CollectionMode { NORMAL, HIDDEN, TRASH }

sealed interface GridRow {
    data class Header(val key: String, val label: String, val ids: List<Long>) : GridRow
    data class Item(val entry: MediaEntry) : GridRow
}

fun formatDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun buildRows(items: List<MediaEntry>, grouping: Grouping, today: String, yesterday: String): List<GridRow> {
    if (grouping == Grouping.NONE) return items.map { GridRow.Item(it) }
    val locale = Locale.getDefault()
    val now = LocalDate.now()
    val dayThisYear = DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)
    val dayOther = DateTimeFormatter.ofPattern("d MMMM yyyy", locale)
    val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy", locale)

    fun keyOf(e: MediaEntry): String {
        val d = e.localDate
        return if (grouping == Grouping.DAY) d.toString() else "${d.year}-${d.monthValue}"
    }

    val rows = ArrayList<GridRow>(items.size + 64)
    var i = 0
    while (i < items.size) {
        val key = keyOf(items[i])
        var j = i
        val ids = ArrayList<Long>()
        while (j < items.size && keyOf(items[j]) == key) {
            ids.add(items[j].id)
            j++
        }
        val d = items[i].localDate
        val label = when {
            grouping == Grouping.MONTH -> d.format(monthFmt)
            d == now -> today
            d == now.minusDays(1) -> yesterday
            d.year == now.year -> d.format(dayThisYear)
            else -> d.format(dayOther)
        }
        rows.add(GridRow.Header(key, label, ids))
        for (k in i until j) rows.add(GridRow.Item(items[k]))
        i = j
    }
    return rows
}

@Composable
fun SelectDot(selected: Boolean, modifier: Modifier = Modifier) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.25f),
        label = "dot"
    )
    Box(
        modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(bg)
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
    }
}

@Composable
fun Thumb(
    entry: MediaEntry,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    selecting: Boolean = false,
    favorite: Boolean = false,
    overlays: Boolean = true,
    shape: Shape = RoundedCornerShape(0.dp),
    sizePx: Int = 300
) {
    val ctx = LocalContext.current
    val request = remember(entry.uri, sizePx) {
        ImageRequest.Builder(ctx).data(entry.uri).size(sizePx).build()
    }
    val scale by animateFloatAsState(if (selected) 0.88f else 1f, label = "thumbScale")
    Box(modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)) {
        AsyncImage(
            model = request,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(if (selected) RoundedCornerShape(10.dp) else shape)
        )
        if (overlays) {
            if (entry.isVideo) {
                Row(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(13.dp))
                    Text(formatDuration(entry.duration), color = Color.White, fontSize = 10.sp)
                }
            }
            if (favorite && !selecting) {
                Icon(
                    Icons.Filled.Favorite, null, tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(5.dp)
                        .size(14.dp)
                )
            }
            if (selecting) SelectDot(selected, Modifier.align(Alignment.TopStart).padding(6.dp))
        }
    }
}

@Composable
fun MediaGrid(
    items: List<MediaEntry>,
    columns: Int,
    grouping: Grouping,
    selected: Set<Long>,
    favorites: Set<Long>,
    onClick: (MediaEntry) -> Unit,
    onLongClick: (MediaEntry) -> Unit,
    onToggleGroup: (List<Long>) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    header: (@Composable () -> Unit)? = null
) {
    val today = stringResource(R.string.today)
    val yesterday = stringResource(R.string.yesterday)
    val rows = remember(items, grouping, today, yesterday) { buildRows(items, grouping, today, yesterday) }
    val selecting = selected.isNotEmpty()

    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        state = state,
        modifier = modifier,
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        if (header != null) {
            item(key = "header", span = { GridItemSpan(maxLineSpan) }) { header() }
        }
        items(
            rows,
            key = { r ->
                when (r) {
                    is GridRow.Header -> "h_" + r.key
                    is GridRow.Item -> r.entry.id
                }
            },
            span = { r -> if (r is GridRow.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1) },
            contentType = { r -> if (r is GridRow.Header) 0 else 1 }
        ) { r ->
            when (r) {
                is GridRow.Header -> {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            r.label,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (selecting) {
                            SelectDot(
                                r.ids.all { it in selected },
                                Modifier.clickable { onToggleGroup(r.ids) }
                            )
                        }
                    }
                }

                is GridRow.Item -> {
                    val e = r.entry
                    Thumb(
                        entry = e,
                        selected = e.id in selected,
                        selecting = selecting,
                        favorite = e.id in favorites,
                        modifier = Modifier
                            .aspectRatio(1f)
                            .combinedClickable(
                                onClick = { onClick(e) },
                                onLongClick = { onLongClick(e) }
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun ActionBar(items: List<Triple<ImageVector, String, () -> Unit>>, modifier: Modifier = Modifier) {
    Surface(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .navigationBarsPadding()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 10.dp,
        tonalElevation = 2.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { (icon, label, onClick) ->
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onClick)
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, label, Modifier.size(24.dp))
                    Text(label, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun SelectionTopBar(
    count: Int,
    allSelected: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.background.copy(alpha = 0.96f)) {
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, null) }
            Text(
                stringResource(R.string.n_selected, count),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSelectAll) {
                Text(stringResource(if (allSelected) R.string.deselect_all else R.string.select_all))
            }
        }
    }
}

/** A media grid with multi-selection and the contextual action bars used across the app. */
@Composable
fun MediaCollection(
    vm: GalleryViewModel,
    items: List<MediaEntry>,
    onOpen: (List<Long>, Int) -> Unit,
    modifier: Modifier = Modifier,
    columns: Int = 4,
    grouping: Grouping = Grouping.DAY,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    header: (@Composable () -> Unit)? = null,
    mode: CollectionMode = CollectionMode.NORMAL,
    onSelecting: (Boolean) -> Unit = {},
    state: LazyGridState = rememberLazyGridState()
) {
    val actions = LocalActions.current
    var selected by remember { mutableStateOf(emptySet<Long>()) }
    val selecting = selected.isNotEmpty()
    val index = remember(items) { items.withIndex().associate { it.value.id to it.index } }
    val ids = remember(items) { items.map { it.id } }

    LaunchedEffect(items) {
        if (selected.isNotEmpty()) selected = selected.filter { it in index }.toSet()
    }
    LaunchedEffect(selecting) { onSelecting(selecting) }
    DisposableEffect(Unit) { onDispose { onSelecting(false) } }
    BackHandler(enabled = selecting) { selected = emptySet() }

    fun toggle(id: Long) {
        selected = if (id in selected) selected - id else selected + id
    }

    fun chosen(): List<MediaEntry> = items.filter { it.id in selected }

    Box(modifier) {
        MediaGrid(
            items = items,
            columns = columns,
            grouping = grouping,
            selected = selected,
            favorites = vm.favorites,
            onClick = { e ->
                if (selecting) toggle(e.id) else onOpen(ids, index[e.id] ?: 0)
            },
            onLongClick = { e -> if (!selecting) selected = setOf(e.id) else toggle(e.id) },
            onToggleGroup = { group ->
                selected = if (group.all { it in selected }) selected - group.toSet() else selected + group
            },
            modifier = Modifier.fillMaxSize(),
            state = state,
            contentPadding = contentPadding,
            header = header
        )

        AnimatedVisibility(
            visible = selecting,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            SelectionTopBar(
                count = selected.size,
                allSelected = selected.size == items.size,
                onClose = { selected = emptySet() },
                onSelectAll = {
                    selected = if (selected.size == items.size) emptySet() else ids.toSet()
                }
            )
        }

        AnimatedVisibility(
            visible = selecting,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            val share = stringResource(R.string.share)
            val delete = stringResource(R.string.delete)
            val favorite = stringResource(R.string.favorite)
            val hide = stringResource(R.string.hide)
            val unhide = stringResource(R.string.unhide)
            val restore = stringResource(R.string.restore)
            val deleteForever = stringResource(R.string.delete_forever)
            val bar: List<Triple<ImageVector, String, () -> Unit>> = when (mode) {
                CollectionMode.NORMAL -> listOf(
                    barItem(Icons.Filled.Share, share) { actions.share(chosen()) },
                    barItem(Icons.Filled.FavoriteBorder, favorite) {
                        vm.toggleFavorite(selected)
                        selected = emptySet()
                    },
                    barItem(Icons.Filled.VisibilityOff, hide) {
                        vm.hide(selected)
                        selected = emptySet()
                    },
                    barItem(Icons.Filled.Delete, delete) {
                        actions.trash(chosen()) { selected = emptySet() }
                    }
                )

                CollectionMode.HIDDEN -> listOf(
                    barItem(Icons.Filled.Share, share) { actions.share(chosen()) },
                    barItem(Icons.Filled.Visibility, unhide) {
                        vm.unhide(selected)
                        selected = emptySet()
                    },
                    barItem(Icons.Filled.Delete, delete) {
                        actions.trash(chosen()) { selected = emptySet() }
                    }
                )

                CollectionMode.TRASH -> listOf(
                    barItem(Icons.Filled.Restore, restore) {
                        actions.restore(chosen()) { selected = emptySet() }
                    },
                    barItem(Icons.Filled.DeleteForever, deleteForever) {
                        actions.deleteForever(chosen()) { selected = emptySet() }
                    }
                )
            }
            ActionBar(bar)
        }
    }
}

private fun barItem(icon: ImageVector, label: String, onClick: () -> Unit): Triple<ImageVector, String, () -> Unit> =
    Triple(icon, label, onClick)
