@file:OptIn(ExperimentalMaterial3Api::class)

package com.hyper.gallery.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyper.gallery.GalleryViewModel
import com.hyper.gallery.R
import com.hyper.gallery.data.MediaEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

data class EditParams(
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val ratio: Float? = null,
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f,
    val filter: Int = 0
)

object ImageEditor {

    val filterNames = listOf(
        R.string.f_original, R.string.f_vivid, R.string.f_mono, R.string.f_sepia,
        R.string.f_cool, R.string.f_warm, R.string.f_fade, R.string.f_noir
    )

    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val s = max(w, h).toFloat() / maxSide
            if (s > 1f) decoder.setTargetSize((w / s).roundToInt(), (h / s).roundToInt())
        }
    }

    fun downscale(src: Bitmap, maxSide: Int): Bitmap {
        val s = max(src.width, src.height).toFloat() / maxSide
        if (s <= 1f) return src
        return Bitmap.createScaledBitmap(
            src, (src.width / s).roundToInt().coerceAtLeast(1), (src.height / s).roundToInt().coerceAtLeast(1), true
        )
    }

    private fun filterMatrix(i: Int): ColorMatrix? = when (i) {
        1 -> ColorMatrix().apply { setSaturation(1.4f) }
        2 -> ColorMatrix().apply { setSaturation(0f) }
        3 -> ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        4 -> ColorMatrix(
            floatArrayOf(
                0.9f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1.15f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        5 -> ColorMatrix(
            floatArrayOf(
                1.15f, 0f, 0f, 0f, 8f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 0.88f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        6 -> ColorMatrix(
            floatArrayOf(
                0.85f, 0f, 0f, 0f, 26f,
                0f, 0.85f, 0f, 0f, 26f,
                0f, 0f, 0.85f, 0f, 26f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        7 -> ColorMatrix().apply {
            setSaturation(0f)
            postConcat(
                ColorMatrix(
                    floatArrayOf(
                        1.35f, 0f, 0f, 0f, -35f,
                        0f, 1.35f, 0f, 0f, -35f,
                        0f, 0f, 1.35f, 0f, -35f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        else -> null
    }

    private fun buildMatrix(p: EditParams): ColorMatrix {
        val cm = ColorMatrix()
        filterMatrix(p.filter)?.let { cm.postConcat(it) }
        cm.postConcat(ColorMatrix().apply { setSaturation(p.saturation) })
        val c = p.contrast
        val t = (1f - c) * 128f + p.brightness * 255f
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val w = p.warmth * 0.2f
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    1f + w, 0f, 0f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f - w, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return cm
    }

    fun render(src: Bitmap, p: EditParams): Bitmap {
        val m = Matrix()
        m.postRotate(p.rotation.toFloat())
        if (p.flipH) m.postScale(-1f, 1f)
        var bmp = if (p.rotation % 360 == 0 && !p.flipH) src
        else Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)

        p.ratio?.let { r ->
            val cur = bmp.width.toFloat() / bmp.height
            var w = bmp.width
            var h = bmp.height
            if (cur > r) w = (bmp.height * r).roundToInt() else h = (bmp.width / r).roundToInt()
            w = w.coerceIn(1, bmp.width)
            h = h.coerceIn(1, bmp.height)
            bmp = Bitmap.createBitmap(bmp, (bmp.width - w) / 2, (bmp.height - h) / 2, w, h)
        }

        val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(buildMatrix(p))
        Canvas(out).drawBitmap(bmp, 0f, 0f, paint)
        return out
    }

    fun save(ctx: Context, original: MediaEntry, bmp: Bitmap): Uri? {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${stamp}_edit.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HyperGallery")
            put(MediaStore.MediaColumns.DATE_TAKEN, original.date)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }
}

private val Ratios = listOf<Pair<Int, Float?>>(
    R.string.ratio_free to null,
    R.string.ratio_1_1 to 1f,
    R.string.ratio_4_3 to 4f / 3f,
    R.string.ratio_3_4 to 3f / 4f,
    R.string.ratio_16_9 to 16f / 9f,
    R.string.ratio_9_16 to 9f / 16f
)

@Composable
fun EditorScreen(vm: GalleryViewModel, nav: Navigator, id: Long) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val entry = vm.find(id)

    var full by remember { mutableStateOf<Bitmap?>(null) }
    var small by remember { mutableStateOf<Bitmap?>(null) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var params by remember { mutableStateOf(EditParams()) }
    var tool by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var filterThumbs by remember { mutableStateOf<List<Bitmap>>(emptyList()) }

    LaunchedEffect(id) {
        if (entry == null) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val f = ImageEditor.decode(ctx, entry.uri, 4096)
                full = f
                small = ImageEditor.downscale(f, 1280)
            } catch (_: Exception) {
            }
        }
    }
    LaunchedEffect(small, params) {
        val s = small ?: return@LaunchedEffect
        preview = withContext(Dispatchers.Default) { ImageEditor.render(s, params) }
    }
    LaunchedEffect(small) {
        val s = small ?: return@LaunchedEffect
        filterThumbs = withContext(Dispatchers.Default) {
            val t = ImageEditor.downscale(s, 128)
            ImageEditor.filterNames.indices.map { ImageEditor.render(t, EditParams(filter = it)) }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { nav.pop() }) { Icon(Icons.Filled.Close, null) }
            Text(
                stringResource(R.string.edit),
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp,
                modifier = Modifier.weight(1f)
            )
            TextButtonReset { params = EditParams() }
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = !saving && full != null && entry != null,
                onClick = {
                    val f = full ?: return@Button
                    val e = entry ?: return@Button
                    saving = true
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) {
                            try {
                                ImageEditor.save(ctx, e, ImageEditor.render(f, params))
                            } catch (_: Exception) {
                                null
                            }
                        }
                        saving = false
                        Toast.makeText(
                            ctx,
                            if (uri != null) R.string.saved else R.string.save_failed,
                            Toast.LENGTH_SHORT
                        ).show()
                        if (uri != null) {
                            vm.refresh()
                            nav.pop()
                        }
                    }
                }
            ) { Text(stringResource(R.string.save)) }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            val p = preview
            if (p != null) {
                Image(
                    bitmap = p.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(12.dp))
                )
            } else {
                CircularProgressIndicator()
            }
            if (saving) CircularProgressIndicator()
        }

        Surface(
            Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(Modifier.navigationBarsPadding().padding(top = 12.dp, bottom = 8.dp)) {
                Box(Modifier.height(110.dp).fillMaxWidth()) {
                    when (tool) {
                        0 -> CropTools(params) { params = it }
                        1 -> AdjustTools(params) { params = it }
                        else -> FilterTools(params, filterThumbs) { params = it }
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ToolTab(Icons.Filled.Crop, stringResource(R.string.tool_crop), tool == 0) { tool = 0 }
                    ToolTab(Icons.Filled.Tune, stringResource(R.string.tool_adjust), tool == 1) { tool = 1 }
                    ToolTab(Icons.Filled.PhotoFilter, stringResource(R.string.tool_filters), tool == 2) { tool = 2 }
                }
            }
        }
    }
}

@Composable
private fun TextButtonReset(onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick) { Text(stringResource(R.string.reset)) }
}

@Composable
private fun ToolTab(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint)
        Text(label, color = tint, fontSize = 12.sp)
    }
}

@Composable
private fun CropTools(p: EditParams, onChange: (EditParams) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(Ratios) { _, (label, ratio) ->
                FilterChip(
                    selected = p.ratio == ratio,
                    onClick = { onChange(p.copy(ratio = ratio)) },
                    label = { Text(stringResource(label)) }
                )
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { onChange(p.copy(rotation = (p.rotation + 270) % 360)) }) {
                Icon(Icons.Filled.RotateLeft, null)
            }
            IconButton(onClick = { onChange(p.copy(rotation = (p.rotation + 90) % 360)) }) {
                Icon(Icons.Filled.RotateRight, null)
            }
            IconButton(onClick = { onChange(p.copy(flipH = !p.flipH)) }) {
                Icon(Icons.Filled.Flip, null)
            }
        }
    }
}

@Composable
private fun AdjustTools(p: EditParams, onChange: (EditParams) -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val names = listOf(R.string.adj_brightness, R.string.adj_contrast, R.string.adj_saturation, R.string.adj_warmth)
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(names) { i, n ->
                FilterChip(selected = page == i, onClick = { page = i }, label = { Text(stringResource(n)) })
            }
        }
        Box(Modifier.padding(horizontal = 24.dp)) {
            when (page) {
                0 -> Slider(p.brightness, { onChange(p.copy(brightness = it)) }, valueRange = -0.4f..0.4f)
                1 -> Slider(p.contrast, { onChange(p.copy(contrast = it)) }, valueRange = 0.6f..1.6f)
                2 -> Slider(p.saturation, { onChange(p.copy(saturation = it)) }, valueRange = 0f..2f)
                else -> Slider(p.warmth, { onChange(p.copy(warmth = it)) }, valueRange = -1f..1f)
            }
        }
    }
}

@Composable
private fun FilterTools(p: EditParams, thumbs: List<Bitmap>, onChange: (EditParams) -> Unit) {
    LazyRow(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        itemsIndexed(ImageEditor.filterNames) { i, name ->
            Column(
                Modifier.clickable { onChange(p.copy(filter = i)) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val t = thumbs.getOrNull(i)
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            if (p.filter == i) 2.dp else 0.dp,
                            MaterialTheme.colorScheme.primary,
                            RoundedCornerShape(12.dp)
                        )
                ) {
                    if (t != null) {
                        Image(
                            t.asImageBitmap(), null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Text(
                    stringResource(name),
                    fontSize = 11.sp,
                    color = if (p.filter == i) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
