@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hyper.gallery.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyper.gallery.GalleryViewModel
import com.hyper.gallery.R
import com.hyper.gallery.data.MediaEntry
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(vm: GalleryViewModel, nav: Navigator, tab: Int, onTab: (Int) -> Unit) {
    var selecting by remember { mutableStateOf(false) }
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val pad = bottomInset + 100.dp

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (tab) {
            0 -> PhotosTab(vm, nav, pad) { selecting = it }
            1 -> AlbumsTab(vm, nav, pad)
            else -> DiscoverTab(vm, nav, pad)
        }
        AnimatedVisibility(
            visible = !selecting,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it }
        ) {
            FloatingNav(tab, onTab)
        }
    }
}

@Composable
private fun FloatingNav(tab: Int, onTab: (Int) -> Unit) {
    val tabs = listOf(
        Triple(Icons.Filled.Photo, R.string.tab_photos, 0),
        Triple(Icons.Filled.Collections, R.string.tab_albums, 1),
        Triple(Icons.Filled.Explore, R.string.tab_discover, 2)
    )
    Surface(
        Modifier
            .navigationBarsPadding()
            .padding(bottom = 14.dp),
        shape = RoundedCornerShape(32.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp,
        tonalElevation = 3.dp
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            tabs.forEach { (icon, label, index) ->
                val active = tab == index
                Row(
                    Modifier
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                            else Color.Transparent
                        )
                        .clickable { onTab(index) }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        icon, null,
                        tint = if (active) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    if (active) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            stringResource(label),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Photos

@Composable
private fun PhotosTab(vm: GalleryViewModel, nav: Navigator, bottomPad: Dp, onSelecting: (Boolean) -> Unit) {
    val items = vm.visible
    val level = ZoomLevels[vm.zoom.coerceIn(0, ZoomLevels.lastIndex)]
    val state = rememberLazyGridState()
    val photos = remember(items) { items.count { !it.isVideo } }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                // Pinch to change the thumbnail size / switch between day and month view.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var acc = 1f
                    do {
                        val ev = awaitPointerEvent()
                        if (ev.changes.size >= 2) {
                            acc *= ev.calculateZoom()
                            if (acc > 1.35f) {
                                vm.changeZoom(-1)
                                acc = 1f
                            } else if (acc < 0.72f) {
                                vm.changeZoom(1)
                                acc = 1f
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        MediaCollection(
            vm = vm,
            items = items,
            onOpen = { ids, i -> nav.push(Screen.Viewer(ids, i)) },
            columns = level.columns,
            grouping = level.grouping,
            contentPadding = PaddingValues(bottom = bottomPad),
            header = { PhotosHeader(vm, nav, photos, items.size - photos) },
            onSelecting = onSelecting,
            state = state
        )
        if (items.isEmpty() && vm.loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }
}

@Composable
private fun PhotosHeader(vm: GalleryViewModel, nav: Navigator, photos: Int, videos: Int) {
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.tab_photos), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text(
                    stringResource(R.string.photos_videos_count, photos, videos),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.larger_thumbs)) },
                        onClick = { vm.changeZoom(-1); menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.smaller_thumbs)) },
                        onClick = { vm.changeZoom(1); menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.trash)) },
                        onClick = { nav.push(Screen.Trash); menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.about)) },
                        onClick = { nav.push(Screen.About); menu = false }
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SearchPill { nav.push(Screen.Search) }
        if (vm.analyzeTotal > 0 && vm.analyzed < vm.analyzeTotal) {
            Spacer(Modifier.height(10.dp))
            Text(
                stringResource(R.string.ai_analyzing, vm.analyzed, vm.analyzeTotal),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { vm.analyzed.toFloat() / vm.analyzeTotal.coerceAtLeast(1) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (!vm.loading && photos + videos == 0) {
            Spacer(Modifier.height(48.dp))
            Text(
                stringResource(R.string.no_media),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun SearchPill(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(10.dp))
            Text(
                stringResource(R.string.search_hint),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            Icon(Icons.Filled.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

// ------------------------------------------------------------------ Albums

@Composable
private fun AlbumsTab(vm: GalleryViewModel, nav: Navigator, bottomPad: Dp) {
    val actions = LocalActions.current
    val albums = vm.albums
    val favTitle = stringResource(R.string.favorites)
    val videosTitle = stringResource(R.string.videos)
    val shotsTitle = stringResource(R.string.screenshots)
    val hiddenTitle = stringResource(R.string.hidden_album)

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPad),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                stringResource(R.string.tab_albums),
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(top = 12.dp, bottom = 4.dp)
            )
        }
        item {
            QuickTile(Icons.Filled.Favorite, favTitle, vm.favoriteItems.size) {
                nav.push(Screen.AlbumDetail("fav", favTitle))
            }
        }
        item {
            QuickTile(Icons.Filled.Videocam, videosTitle, vm.videos.size) {
                nav.push(Screen.AlbumDetail("videos", videosTitle))
            }
        }
        item {
            QuickTile(Icons.Filled.Smartphone, shotsTitle, vm.screenshots.size) {
                nav.push(Screen.AlbumDetail("shots", shotsTitle))
            }
        }
        item {
            QuickTile(Icons.Filled.Lock, hiddenTitle, vm.hiddenItems.size) {
                actions.authenticate { nav.push(Screen.Hidden) }
            }
        }
        item {
            QuickTile(Icons.Filled.Delete, stringResource(R.string.trash), vm.trashed.size) {
                nav.push(Screen.Trash)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                stringResource(R.string.all_albums),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        items(albums, key = { it.key }) { album ->
            Column(Modifier.clickable { nav.push(Screen.AlbumDetail(album.key, album.name)) }) {
                Thumb(
                    album.cover,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    overlays = false,
                    shape = RoundedCornerShape(20.dp),
                    sizePx = 400
                )
                Text(
                    album.name,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp, start = 4.dp)
                )
                Text(
                    album.count.toString(),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickTile(icon: ImageVector, title: String, count: Int, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(count.toString(), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------------ Discover

@Composable
private fun DiscoverTab(vm: GalleryViewModel, nav: Navigator, bottomPad: Dp) {
    val years = vm.onThisDayYears
    val months = vm.months
    val smart = vm.smartAlbums
    val locale = Locale.getDefault()
    val monthFmt = remember { DateTimeFormatter.ofPattern("MMMM yyyy", locale) }
    val onThisDay = stringResource(R.string.on_this_day)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                stringResource(R.string.tab_discover),
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(start = 20.dp, top = 12.dp, end = 20.dp)
            )
        }
        if (years.isNotEmpty()) {
            item { SectionTitle(onThisDay) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(years, key = { it.year }) { y ->
                        DiscoverCard(y.cover, y.year.toString(), y.count.toString()) {
                            nav.push(Screen.AlbumDetail("otd:${y.year}", "$onThisDay · ${y.year}"))
                        }
                    }
                }
            }
        }
        if (smart.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.smart_albums)) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(smart, key = { it.def.id }) { s ->
                        val name = smartName(s.def.id)
                        DiscoverCard(s.cover, name, s.count.toString()) {
                            nav.push(Screen.AlbumDetail("smart:${s.def.id}", name))
                        }
                    }
                }
            }
        }
        if (months.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.memories_by_month)) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(months, key = { it.key }) { m ->
                        val label = LocalDate.of(m.year, m.month, 1).format(monthFmt)
                        DiscoverCard(m.cover, label, m.count.toString()) {
                            nav.push(Screen.AlbumDetail("month:${m.key}", label))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun smartName(id: String): String = stringResource(
    when (id) {
        "people" -> R.string.smart_people
        "pets" -> R.string.smart_pets
        "food" -> R.string.smart_food
        "nature" -> R.string.smart_nature
        "buildings" -> R.string.smart_buildings
        "vehicles" -> R.string.smart_vehicles
        else -> R.string.smart_documents
    }
)

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
    )
}

@Composable
private fun DiscoverCard(cover: MediaEntry, title: String, subtitle: String, onClick: () -> Unit) {
    Box(
        Modifier
            .width(160.dp)
            .height(210.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
    ) {
        Thumb(cover, Modifier.fillMaxSize(), overlays = false, sizePx = 500)
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f)),
                        startY = 220f
                    )
                )
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp)
        ) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
            Text(subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
        }
    }
}
