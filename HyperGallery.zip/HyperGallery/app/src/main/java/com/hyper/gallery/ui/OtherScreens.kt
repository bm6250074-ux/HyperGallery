@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hyper.gallery.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyper.gallery.GalleryViewModel
import com.hyper.gallery.R
import com.hyper.gallery.data.MediaEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun DetailHeader(title: String, count: Int, onBack: () -> Unit, extra: (@Composable () -> Unit)? = null) {
    Column(
        Modifier
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    stringResource(R.string.items_count, count),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (extra != null) extra()
    }
}

@Composable
private fun bottomPad() = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 24.dp

@Composable
fun AlbumDetailScreen(vm: GalleryViewModel, nav: Navigator, key: String, title: String) {
    val items = remember(vm.media, vm.hidden, vm.favorites, vm.labelVersion, key) { vm.itemsFor(key) }
    MediaCollection(
        vm = vm,
        items = items,
        onOpen = { ids, i -> nav.push(Screen.Viewer(ids, i)) },
        columns = 4,
        grouping = if (key.startsWith("month:")) Grouping.DAY else Grouping.DAY,
        contentPadding = PaddingValues(bottom = bottomPad()),
        header = { DetailHeader(title, items.size) { nav.pop() } },
        mode = if (key == "hidden") CollectionMode.HIDDEN else CollectionMode.NORMAL
    )
}

@Composable
fun HiddenScreen(vm: GalleryViewModel, nav: Navigator) {
    val items = vm.hiddenItems
    MediaCollection(
        vm = vm,
        items = items,
        onOpen = { ids, i -> nav.push(Screen.Viewer(ids, i)) },
        columns = 4,
        grouping = Grouping.DAY,
        contentPadding = PaddingValues(bottom = bottomPad()),
        header = { DetailHeader(stringResource(R.string.hidden_album), items.size) { nav.pop() } },
        mode = CollectionMode.HIDDEN
    )
}

@Composable
fun TrashScreen(vm: GalleryViewModel, nav: Navigator) {
    val actions = LocalActions.current
    val items = vm.trashed
    MediaCollection(
        vm = vm,
        items = items,
        onOpen = { ids, i -> nav.push(Screen.Viewer(ids, i, trash = true)) },
        columns = 4,
        grouping = Grouping.DAY,
        contentPadding = PaddingValues(bottom = bottomPad()),
        header = {
            DetailHeader(stringResource(R.string.trash), items.size, { nav.pop() }) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                    Text(
                        stringResource(R.string.trash_note),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (items.isNotEmpty()) {
                        TextButton(onClick = { actions.deleteForever(items) {} }) {
                            Icon(Icons.Filled.DeleteForever, null, Modifier.size(18.dp))
                            Text(stringResource(R.string.empty_trash), modifier = Modifier.padding(start = 6.dp))
                        }
                    }
                }
            }
        },
        mode = CollectionMode.TRASH
    )
}

@Composable
fun SearchScreen(vm: GalleryViewModel, nav: Navigator) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    var results by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    val focus = remember { FocusRequester() }
    val active = query.isNotBlank() || filter != 0

    LaunchedEffect(query, filter, vm.visible, vm.labelVersion) {
        if (!active) {
            results = emptyList()
            return@LaunchedEffect
        }
        delay(180)
        results = withContext(Dispatchers.Default) { vm.search(query, filter) }
    }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (_: Exception) {
        }
    }

    val chips = listOf(
        R.string.filter_all, R.string.filter_photos, R.string.filter_videos,
        R.string.filter_screenshots, R.string.favorites
    )

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            TextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                placeholder = { Text(stringResource(R.string.search_hint)) },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, null) }
                    }
                }
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(chips) { i, label ->
                FilterChip(
                    selected = filter == i,
                    onClick = { filter = i },
                    label = { Text(stringResource(label)) }
                )
            }
        }
        if (vm.analyzeTotal > 0 && vm.analyzed < vm.analyzeTotal) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(
                    stringResource(R.string.ai_analyzing, vm.analyzed, vm.analyzeTotal),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { vm.analyzed.toFloat() / vm.analyzeTotal.coerceAtLeast(1) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        if (!active) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.AutoAwesome, null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.search_tips),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(Modifier.weight(1f)) {
                MediaCollection(
                    vm = vm,
                    items = results,
                    onOpen = { ids, i -> nav.push(Screen.Viewer(ids, i)) },
                    columns = 4,
                    grouping = Grouping.NONE,
                    contentPadding = PaddingValues(top = 8.dp, bottom = bottomPad()),
                    modifier = Modifier.fillMaxSize()
                )
                if (results.isEmpty()) {
                    Text(
                        stringResource(R.string.no_results),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AboutScreen(nav: Navigator) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        DetailHeader(stringResource(R.string.about), 0, { nav.pop() })
        Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(stringResource(R.string.app_name), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("v1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.about_body), lineHeight = 22.sp)
            Spacer(Modifier.height(16.dp))
            Text(
                stringResource(R.string.about_disclaimer),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.Photo, null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(72.dp)
        )
        Spacer(Modifier.height(20.dp))
        Text(
            stringResource(R.string.permission_title),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.permission_msg),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGrant) { Text(stringResource(R.string.grant_access)) }
    }
}
