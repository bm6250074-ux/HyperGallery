package com.hyper.gallery.ui

import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.staticCompositionLocalOf
import com.hyper.gallery.data.MediaEntry

sealed interface Screen {
    data class AlbumDetail(val key: String, val title: String) : Screen
    data class Viewer(val ids: List<Long>, val index: Int, val trash: Boolean = false) : Screen
    data class Editor(val id: Long) : Screen
    data object Search : Screen
    data object Trash : Screen
    data object Hidden : Screen
    data object About : Screen
}

class Navigator(private val stack: SnapshotStateList<Screen>) {
    fun push(s: Screen) {
        stack.add(s)
    }

    fun pop() {
        if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
    }
}

/** System-level operations implemented by the activity (permission dialogs, sharing, auth). */
class MediaActions(
    val trash: (List<MediaEntry>, () -> Unit) -> Unit,
    val restore: (List<MediaEntry>, () -> Unit) -> Unit,
    val deleteForever: (List<MediaEntry>, () -> Unit) -> Unit,
    val share: (List<MediaEntry>) -> Unit,
    val setAs: (MediaEntry) -> Unit,
    val authenticate: (() -> Unit) -> Unit
)

val LocalActions = staticCompositionLocalOf<MediaActions> { error("MediaActions not provided") }

data class ZoomLevel(val columns: Int, val grouping: Grouping)

val ZoomLevels = listOf(
    ZoomLevel(3, Grouping.DAY),
    ZoomLevel(4, Grouping.DAY),
    ZoomLevel(5, Grouping.DAY),
    ZoomLevel(7, Grouping.MONTH)
)
