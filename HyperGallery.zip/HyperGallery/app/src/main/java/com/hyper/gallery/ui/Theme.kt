package com.hyper.gallery.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AccentOrange = Color(0xFFFF6900)

@Composable
fun GalleryTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(
            primary = AccentOrange,
            onPrimary = Color.White,
            background = Color(0xFF000000),
            onBackground = Color(0xFFF2F2F2),
            surface = Color(0xFF151515),
            onSurface = Color(0xFFF2F2F2),
            surfaceVariant = Color(0xFF232323),
            onSurfaceVariant = Color(0xFF9A9A9A)
        )
    } else {
        lightColorScheme(
            primary = AccentOrange,
            onPrimary = Color.White,
            background = Color(0xFFF6F6F6),
            onBackground = Color(0xFF121212),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF121212),
            surfaceVariant = Color(0xFFEAEAEA),
            onSurfaceVariant = Color(0xFF6E6E6E)
        )
    }
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
