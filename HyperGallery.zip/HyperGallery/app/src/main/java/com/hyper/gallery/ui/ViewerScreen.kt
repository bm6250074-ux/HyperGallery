@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hyper.gallery.ui

import android.content.Context
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.hyper.gallery.GalleryViewModel
import com.hyper.gallery.R
import com.hyper.gallery.data.MediaEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun ViewerScreen(vm: GalleryViewModel, nav: Navigator, ids: List<Long>, start: Int, trash: Boolean) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val pager = rememberPagerState(
        initialPage = start.coerceIn(0, (ids.size - 1).coerceAtLeast(0))
    ) { ids.size }
    var chrome by remember { mutableStateOf(true) }
    var slideshow by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val entry = ids.getOrNull(pager.currentPage)?.let { vm.find(it) }
    val isFav = entry != null && entry.id in vm.favorites
    val showChrome = chrome || entry?.isVideo == true

    BackHandler(enabled = slideshow) { slideshow = false }

    LaunchedEffect(slideshow, pager.currentPage) {
        if (slideshow) {
            delay(3000)
            if (pager.currentPage < ids.size - 1) pager.animateScrollToPage(pager.currentPage + 1)
            else slideshow = false
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        HorizontalPager(
            state = pager,
            key = { ids[it] },
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val e = vm.find(ids[page])
            if (e == null) {
                Box(Modifier.fillMaxSize())
            } else if (e.isVideo) {
                VideoPage(e, current = pager.currentPage == page)
            } else {
                ZoomableImage(e) { chrome = !chrome }
            }
        }

        // top bar
        AnimatedVisibility(
            visible = showChrome && !slideshow,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.background.copy(alpha = 0.82f)) {
                Row(
                    Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                    Column(Modifier.weight(1f)) {
                        if (entry != null) {
                            val zone = ZoneId.systemDefault()
                            val locale = Locale.getDefault()
                            val z = Instant.ofEpochMilli(entry.date).atZone(zone)
                            Text(
                                z.format(DateTimeFormatter.ofPattern("d MMMM yyyy", locale)),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                            Text(
                                z.format(DateTimeFormatter.ofPattern("EEEE, HH:mm", locale)),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        "${pager.currentPage + 1}/${ids.size}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            }
        }

        // bottom action bar
        AnimatedVisibility(
            visible = showChrome && !slideshow && entry != null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            val e = entry
            if (e != null) {
                val share = stringResource(R.string.share)
                val favorite = stringResource(R.string.favorite)
                val edit = stringResource(R.string.edit)
                val delete = stringResource(R.string.delete)
                val more = stringResource(R.string.more)
                val restore = stringResource(R.string.restore)
                val deleteForever = stringResource(R.string.delete_forever)
                val bar = if (trash) {
                    listOf(
                        viewerItem(Icons.Filled.Restore, restore) {
                            actions.restore(listOf(e)) { nav.pop() }
                        },
                        viewerItem(Icons.Filled.DeleteForever, deleteForever) {
                            actions.deleteForever(listOf(e)) { nav.pop() }
                        }
                    )
                } else {
                    buildList {
                        add(viewerItem(Icons.Filled.Share, share) { actions.share(listOf(e)) })
                        add(
                            viewerItem(
                                if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                favorite
                            ) { vm.toggleFavorite(listOf(e.id)) }
                        )
                        if (!e.isVideo && e.id != -1L) {
                            add(viewerItem(Icons.Filled.Edit, edit) { nav.push(Screen.Editor(e.id)) })
                        }
                        if (e.id != -1L) {
                            add(viewerItem(Icons.Filled.Delete, delete) {
                                actions.trash(listOf(e)) { nav.pop() }
                            })
                        }
                        add(viewerItem(Icons.Filled.MoreVert, more) { menu = true })
                    }
                }
                ActionBar(bar)
            }
        }

        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(bottom = 84.dp, end = 20.dp)
        ) {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.details)) },
                    onClick = { showDetails = true; menu = false }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.slideshow)) },
                    onClick = { slideshow = true; chrome = false; menu = false }
                )
                if (entry != null) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.set_as)) },
                        onClick = { actions.setAs(entry); menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.hide)) },
                        onClick = {
                            vm.hide(listOf(entry.id))
                            menu = false
                            nav.pop()
                        }
                    )
                }
            }
        }
    }

    if (showDetails && entry != null) {
        DetailsDialog(entry) { showDetails = false }
    }
}

private fun viewerItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
): Triple<androidx.compose.ui.graphics.vector.ImageVector, String, () -> Unit> =
    Triple(icon, label, onClick)

private fun clampOffset(o: Offset, scale: Float, size: IntSize): Offset {
    val mx = size.width * (scale - 1f) / 2f
    val my = size.height * (scale - 1f) / 2f
    return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
}

@Composable
private fun ZoomableImage(entry: MediaEntry, onTap: () -> Unit) {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val tap by rememberUpdatedState(onTap)
    val request = remember(entry.uri) {
        ImageRequest.Builder(ctx).data(entry.uri).size(2400).crossfade(true).build()
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { box = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { tap() },
                    onDoubleTap = { p ->
                        if (scale > 1f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            val c = Offset(box.width / 2f, box.height / 2f)
                            scale = 2.5f
                            offset = clampOffset((c - p) * 1.5f, 2.5f, box)
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        if (ev.changes.size > 1 || scale > 1f) {
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale <= 1f) Offset.Zero
                            else clampOffset(offset + pan, scale, box)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
    ) {
        AsyncImage(
            model = request,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                }
        )
    }
}

@Composable
private fun VideoPage(entry: MediaEntry, current: Boolean) {
    val ctx = LocalContext.current
    if (!current) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(entry.uri).size(1080).build(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
            Icon(
                Icons.Filled.PlayArrow, null, tint = Color.White,
                modifier = Modifier
                    .size(64.dp)
                    .background(Color.Black.copy(alpha = 0.4f), androidx.compose.foundation.shape.CircleShape)
            )
        }
        return
    }
    val player = remember(entry.uri) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(entry.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun DetailsDialog(entry: MediaEntry, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val exif by produceState<List<Pair<Int, String>>>(emptyList(), entry.id) {
        value = withContext(Dispatchers.IO) { readExif(ctx, entry) }
    }
    val locale = Locale.getDefault()
    val date = Instant.ofEpochMilli(entry.date).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMMM yyyy, HH:mm", locale))
    val rows = buildList<Pair<Int, String>> {
        add(R.string.d_name to entry.name)
        add(R.string.d_date to date)
        add(R.string.d_path to (entry.path + entry.name))
        add(R.string.d_size to Formatter.formatFileSize(ctx, entry.size))
        if (entry.width > 0) {
            val mp = entry.width.toLong() * entry.height / 1_000_000.0
            add(R.string.d_resolution to "${entry.width} × ${entry.height}  (%.1f MP)".format(mp))
        }
        add(R.string.d_type to entry.mime)
        if (entry.isVideo) add(R.string.d_duration to formatDuration(entry.duration))
        addAll(exif)
    }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.ok)) } },
        title = { Text(stringResource(R.string.details)) },
        text = {
            Column {
                rows.forEach { (label, value) ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Text(
                            stringResource(label),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(value, fontSize = 14.sp)
                    }
                }
            }
        }
    )
}

private fun readExif(ctx: Context, e: MediaEntry): List<Pair<Int, String>> {
    if (e.isVideo) return emptyList()
    return try {
        ctx.contentResolver.openInputStream(e.uri)?.use { s ->
            val x = ExifInterface(s)
            buildList<Pair<Int, String>> {
                val cam = listOfNotNull(
                    x.getAttribute(ExifInterface.TAG_MAKE),
                    x.getAttribute(ExifInterface.TAG_MODEL)
                ).joinToString(" ")
                if (cam.isNotBlank()) add(R.string.d_camera to cam)
                x.getAttribute(ExifInterface.TAG_F_NUMBER)?.let { add(R.string.d_aperture to "f/$it") }
                x.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)?.let { add(R.string.d_exposure to "${it}s") }
                x.getAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY)?.let { add(R.string.d_iso to "ISO $it") }
                val fl = x.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0)
                if (fl > 0) add(R.string.d_focal to "%.1f mm".format(fl))
            }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}
